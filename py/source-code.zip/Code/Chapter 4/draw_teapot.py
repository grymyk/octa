from teapot import load_triangles
from draw_model import draw_model

draw_model(load_triangles())
